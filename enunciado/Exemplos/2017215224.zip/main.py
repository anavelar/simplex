line = input()
print(
	"otima" + '\n' + 
	"14" + '\n' + 
	"1 1 1" + '\n' +
	"2 4 8")
