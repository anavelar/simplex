#!/bin/bash
python3 main.py < $1 > $2
