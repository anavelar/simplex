#!/bin/bash
java Main < $1 > $2
