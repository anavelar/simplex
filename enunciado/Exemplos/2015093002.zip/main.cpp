#include <iostream>
int main(){
	while (std::cin) std::cin.ignore();
	std::cout << 
	"otima" << std::endl << 
	"14" << std::endl << 
	"1 1 1" << std::endl <<
	"2 4 8" << std::endl;
	return 0;
}
