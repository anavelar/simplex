#!/bin/bash
g++ main.cpp
