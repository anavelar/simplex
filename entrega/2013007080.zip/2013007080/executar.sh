#!/bin/bash
./executavel < $1 > $2
